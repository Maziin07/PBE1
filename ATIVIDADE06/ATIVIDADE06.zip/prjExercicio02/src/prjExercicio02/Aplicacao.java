package prjExercicio02;

public class Aplicacao {
	
	public static void main(String[] args) {
		
		Livro alice = new Livro();
		alice.titulo = "Alice no país das Maravilhas";
		alice.autor = "Lewis Carroll"; 
		alice.numPaginas = 224;
		alice.preco = 100;
		
		alice.exibirinfo();
		alice.aplicarDesconto(15);
		alice.exibirinfo();
		
		 Livro oPequenoPrincipe = new Livro();
	     oPequenoPrincipe.titulo = "O Pequeno Príncipe";
	     oPequenoPrincipe.autor = "Antoine de Saint-Exupéry";
	     oPequenoPrincipe.numPaginas = 96;
	     oPequenoPrincipe.preco = 75;
		
	     oPequenoPrincipe.exibirinfo();
	     oPequenoPrincipe.aplicarDesconto(15);
		 oPequenoPrincipe.exibirinfo();
		 
		 Livro oHobbit = new Livro();
	     oHobbit.titulo = "O Hobbit";
	     oHobbit.autor = "J.R.R. Tolkien";
	     oHobbit.numPaginas = 320;
	     oHobbit.preco = 120;
	     
	     oHobbit.exibirinfo();
	     oHobbit.aplicarDesconto(15);
		 oHobbit.exibirinfo();
			
	     
	}
}
