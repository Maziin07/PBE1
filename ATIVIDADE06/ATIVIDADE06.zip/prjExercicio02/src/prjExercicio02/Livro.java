package prjExercicio02;

public class Livro {

	//Atributos
	
	String titulo;
	String autor;
	int numPaginas;
	int preco;
	int desconto = 15;
	
	//Construtores

		public Livro () {
		}
		
		public Livro(String titulo, String autor, int numPaginas, int preco) {
			
			this.titulo = titulo;
			this.autor = autor;
			this.numPaginas = numPaginas;
			this.preco = preco;
			}	
		
		

		//Metodos
		
		public void exibirinfo() {
			
			System.out.println("Titulo: " + this.titulo);
			System.out.println("Autor: " + this.autor);
			System.out.println("Numero de Paginas: " + this.numPaginas);
			System.out.println("Preço: " + this.preco);
		    }
			
		 
			public void aplicarDesconto(double desconto) {
		        if (desconto < preco) {
		            preco -= desconto;
			}
			
		}
		
	
		//Getters e Setters
		
	    public String titulo() {
			return titulo;
		}
		public void setTitulo(String titulo) {
			this.titulo = titulo;
		}
		public String getAutor() {
			return autor;
		}
		public void setAutor(String autor) {
			this.autor = autor;
		}
		public int getNumero() {
			return numPaginas;
		}
		public void setNumero(int numPaginas) {
			this.numPaginas = numPaginas;
		}
		public int getPreco() {
			return preco;
		}
		public void setPreco(int preco) {
			this.preco = preco;
		}

		
}
