package prjExercicio03;

public class SubclasseLeao extends Animal {

	public static void main(String[] args) {}
		
		//Metodos da SubClasse
	
	    public void metodoCacar() {
	        System.out.println(this.nome + " está caçando.");
	}
  }
	
