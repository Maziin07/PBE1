package prjExercicio03;

public class SubclasseBaleia extends Animal {

	//Metodos da SubClasse
	
	public static void main(String[] args) {}
	
		public void metodoNadar() {
			System.out.println(this.nome + " está nadando.");
		}

		
	}