package prjExercicio03;

public class Animal {

	//Atributos
	
	String nome;
	int idade;
	String raca;
	
	//Construtores
	
	public Animal () {
	}
	
	public Animal(String nome, String raca, int idade) {
		
		this.nome = nome;
		this.raca = raca;
		this.idade = idade;
		}
	
	//Metodos
	
	public void fazerSom() {
		System.out.println(this.nome + " fez um som.");
	}		
	
	public void metodoCacar() {
		System.out.println(this.nome + " está caçando.");
	}		
	
	public void metodoNadar() {
		System.out.println(this.nome + " está nadando.");
	}
	
	
}
