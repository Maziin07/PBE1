package prjExercicio03;

public class Animal {

	String nome;
	int idade;
	String raca;
	
	//Construtores
	
	public Animal () {
	}
	
	public Animal(String nome, String raca, int idade) {
		
		this.nome = nome;
		this.raca = raca;
		this.idade = idade;
		}
	
	
}
