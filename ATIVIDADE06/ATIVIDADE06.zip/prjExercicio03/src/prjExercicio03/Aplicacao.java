package prjExercicio03;

public class Aplicacao {
	
public static void main(String[] args) {
		
		Animal leao = new Animal();
		leao.nome = "Leandro";
		leao.raca = "Macho"; 
		leao.idade = 34;
		
		Animal baleia = new Animal();
		baleia.nome = "Carlos";
		baleia.raca = "Macho"; 
		baleia.idade = 54;
		
		leao.fazerSom();
		baleia.fazerSom();
		
		leao.metodoCacar();
		baleia.metodoNadar();
		
	}
}