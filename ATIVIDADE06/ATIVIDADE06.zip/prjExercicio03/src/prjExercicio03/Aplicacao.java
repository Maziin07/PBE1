package prjExercicio03;

public class Aplicacao {
	
public static void main(String[] args) {
		
		Animal leao = new Animal();
		leao.nome = "Leandro";
		leao.raca = "Macho"; 
		leao.idade = 34;
		
		Animal baleia = new Animal();
		baleia.nome = "Leandro";
		baleia.raca = "Macho"; 
		baleia.idade = 34;
		
		leao.metodoCacar
		baleia.metodoNadar
		
	}
}
