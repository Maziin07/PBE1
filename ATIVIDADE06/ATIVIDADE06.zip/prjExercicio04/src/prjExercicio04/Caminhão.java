package prjExercicio04;

public class Caminhão extends Veiculo {

	//Metodos da SubClasse
	
	public static void main(String[] args) {}
	
		public void caminhãoAcelerar() {
			System.out.println(this.velocidade += 10);
			System.out.println("Caminhão está acelerando");
		}{

}
