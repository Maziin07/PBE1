package prjExercicio04;

public class Carro extends Veiculo {

	//Metodos da SubClasse
	
	public static void main(String[] args) {}
	
		public void carroAcelerar() {
			System.out.println(this.velocidade += 10);
			System.out.println("Carro está acelerando");{

				
			}
		}
	}
