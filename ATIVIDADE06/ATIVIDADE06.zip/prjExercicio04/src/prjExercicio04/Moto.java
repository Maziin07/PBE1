package prjExercicio04;

public class Moto extends Veiculo {

	//Metodos da SubClasse
	
	public static void main(String[] args) {}
	
		public void motoAcelerar() {
			System.out.println(this.velocidade += 10);
			System.out.println("Moto está acelerando"); {

				
				
			}
		}
	}
