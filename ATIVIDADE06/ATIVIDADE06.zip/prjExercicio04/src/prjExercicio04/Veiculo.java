package prjExercicio04;

public class Veiculo {

	//Atributos
	
		String marca;
		int velocidade;
		String modelo;
		
		
	//Construtores
		
		public Veiculo () {
		}
		
		public Veiculo(String marca, String modelo, int velocidade) {
			
			this.marca = marca;
			this.modelo = modelo;
			this.velocidade = velocidade;
			}
		
	//Metodos
		
		public void acelerar() {
			System.out.println(this.velocidade += 10);
			System.out.println("Veiculo acelerando");
		}		
		
		public void frear() {
			System.out.println(this.velocidade -= 10);
			System.out.println("Veiculo freando");
		}		
		
}
