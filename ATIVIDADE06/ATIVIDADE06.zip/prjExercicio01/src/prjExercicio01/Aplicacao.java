package prjExercicio01;

public class Aplicacao {

	public static void main(String[] args) {
		
		Carro gt3 = new Carro();
		gt3.marca = "Porsche";
		gt3.modelo = "GT3"; 
		gt3.placa = "ABC123";
		gt3.ano = 2022;
		
		gt3.exibirinfo();
		
		Carro gtr = new Carro();
		gtr.marca = "Nissan";
		gtr.modelo = "GTR"; 
		gtr.placa = "123ABC";
		gtr.ano = 2022;
		
		gtr.exibirinfo();
		
		
	}	
}
