package prjExercicio01;

public class Carro {

	//Atributos
			
	String marca;
	String modelo;
	String placa;
	int ano;

	
	//Construtores

	public Carro() {
	}
	
	public Carro(String marca, 	String modelo, String placa, int ano) {
		
		this.marca = marca;
		this.modelo = modelo;
		this.placa = placa;
		this.ano = ano;
		}
	
	//Metodos
	
	public void exibirinfo() {
		
		System.out.println("Marca: " + this.marca);
		System.out.println("Modelo: " + this.modelo);
		System.out.println("Placa: " + this.placa);
		System.out.println("Ano: " + this.ano);
		
	}
	
	
			
}
