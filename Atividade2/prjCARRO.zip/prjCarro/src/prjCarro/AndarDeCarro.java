package prjCarro;

import java.util.Scanner;

public class AndarDeCarro {

	public static void main(String[] args) {

		 int valor = 0;
		
		String acelerar;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Qual a Marca do Carro?");
		String marca = sc.next();
		
		System.out.println("Qual o modelo do Carro?");
		String modelo = sc.next();
		
		System.out.println("Digite a Velocidade Inicial: ");
		int velocidade = sc.nextInt();
		
		System.out.println("Opções: ");
		System.out.println("1. Acelerar");
        System.out.println("2. Frear");
        System.out.println("Escolha uma opção: ");
        int escolha = sc.nextInt();
        
        if (escolha == 1) {
        	System.out.println("Quanto você quer acelerar? ");
        	int valor1 = sc.nextInt();  }
			velocidade += valor;
	
	    if (escolha == 2) {
		System.out.println("Quanto você quer desacelerar?");
		int valor1 = sc.nextInt();
	                           }
	
	    else {  
		System.out.println("Opção Invalida");
	         }
		
		
	}

}
