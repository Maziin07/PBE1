package prjContaBancaria;

import java.util.Scanner;

public class Conta1 {

	public static void main(String[] args) {

		 int valor = 0;
		 int valor1;
		
		String acelerar;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Qual é o numero da conta?");
		int numeroConta = sc.nextInt();
		
		System.out.println("Qual é o nome do titular da conta?");
		String nomeTitular = sc.next();
		
		System.out.println("Digite o Saldo Inicial: ");
		double saldo = sc.nextInt();
		
		System.out.println("Opções: ");
		System.out.println("1. Depositar");
       System.out.println("2. Sacar");
       System.out.println("3. Exibir Informações");
       int escolha = sc.nextInt();
       
       if (escolha == 1) {
       	System.out.println("Quanto você quer depositar? ");
       	double valor = sc.nextInt();  }
			valor += valor1;
	
	    if (escolha == 2) {
		System.out.println("Quanto você quer sacar?");
		int valor = sc.nextInt();
		    valor -= valor1;
	                           }
	
	    else {  
		System.out.println("Opção Invalida");
	         }
		
	    
	
   }
}
