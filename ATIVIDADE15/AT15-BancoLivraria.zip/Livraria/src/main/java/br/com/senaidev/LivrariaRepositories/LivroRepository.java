package br.com.senaidev.LivrariaRepositories;

public interface LivroRepository {

}
