package br.com.senaidev.LivrariaEntities;

public class Cliente {

}
