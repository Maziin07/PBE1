package br.com.senaidev.Livraria;

public class LivrariaApplication {

}
