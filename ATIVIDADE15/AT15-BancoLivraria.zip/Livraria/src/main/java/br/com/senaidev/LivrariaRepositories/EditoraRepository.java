package br.com.senaidev.LivrariaRepositories;

public interface EditoraRepository {

}
