package br.com.senaidev.LivrariaEntities;

public class Pedido {

}
