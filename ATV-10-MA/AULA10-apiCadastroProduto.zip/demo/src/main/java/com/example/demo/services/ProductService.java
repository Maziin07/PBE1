package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Product;
import com.example.demo.repositories.ProductRepository;

@Service
public class ProductService {
   
    @Autowired
    private final ProductRepository productrepository;
    @Autowired
    public ProductService(ProductRepository productrepository) {
        this.productrepository = productrepository;
    }
   
    public Product saveProduct(Product product) {
        return productrepository.save(product);
       
    }
   
    public Product getproductById(Long id) {
        return productrepository.findById(id).orElse(null);
    }

    public List<Product> getAllProducts(){
        return productrepository.findAll();
    }
   
    public void deleteProduct(Long id) {
        productrepository.deleteById(id);
    }
   
    public Product updateProduct(Long id, Product produtoAtualizado) {
    	//criando o optional para receber o produto
    	Optional<Product> produtoOptional = productrepository.findById(id);
    	if(produtoOptional.isPresent()) {
    		//se encontrou
    		Product productExistente = produtoOptional.get();
    		productExistente.setName(produtoAtualizado.getName());
    		productExistente.setPrice(produtoAtualizado.getPrice());
    		return productrepository.save(productExistente);
    	}else {
    		//se não encontrou
    		return null;
    	}
    }
}