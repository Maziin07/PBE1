package com.senaidev.login.entitites.curso;


@Entity
public class Curso {
	
		//Atributos
	
		@Id
		private int id_curso;
		private String nomecurso;
		private String descricao;
		private int carga;
		private int ano;
		
		//Construtores
		
		public Curso() {	
		}

		public Curso(String nomecurso, String descricao, int carga, int ano) {
			super();
			this.nomecurso = nomecurso;
			this.descricao = descricao;
			this.carga = carga;
			this.ano = ano;
		
		//Getters and Setters
		
		}
		public String getNomecurso() {
			return nomecurso;
		}
		public void setNomecurso(String nomecurso) {
			this.nomecurso = nomecurso;
		}
		public String getDescricao() {
			return descricao;
		}
		public void setDescricao(String descricao) {
			this.descricao = descricao;
		}
		public int getCarga() {
			return carga;
		}
		public void setCarga(int carga) {
			this.carga = carga;
		}
		public int getAno() {
			return ano;
		}
		public void setAno(int ano) {
			this.ano = ano;
		}
		
}
