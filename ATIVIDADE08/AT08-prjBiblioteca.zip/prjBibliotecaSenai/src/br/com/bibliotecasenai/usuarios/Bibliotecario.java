package br.com.bibliotecasenai.usuarios;

public class Bibliotecario extends Pessoa {
	
	//ATRIBUTOS
	private String matricula;
	
	//MÉTODOS
	//Realizar empréstimo
	public void realizarEmpréstimo() {
		System.out.println(getNome() + " realizou o empréstimo de um livro.");
	}
	
	//Devolver livro
	public void devolverLivro() {
		System.out.println(getNome() + " devolveu o livro com sucesso.");
	}
}
