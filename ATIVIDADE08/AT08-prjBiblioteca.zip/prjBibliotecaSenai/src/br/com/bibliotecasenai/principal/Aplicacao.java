package br.com.bibliotecasenai.principal;

import br.com.bibliotecasenai.usuarios.Bibliotecario;
import br.com.bibliotecasenai.usuarios.Usuario;

public class Aplicacao {

	public static void main(String[] args) {
		
		//Criação dos usuários
		Usuario usuario01 = new Usuario();
		usuario01.setNome("Josefina");
		usuario01.setCpf(908678789);
		usuario01.setIdade(23);
		
		Usuario usuario02 = new Usuario();
		usuario02.setNome("Lais");
		usuario02.setCpf(452647526);
		usuario02.setIdade(19);
		
		//Empréstimos e devoluções
		for(int i = 0; i < 10; i++) {
			//emprestarLivro()
		}
		for(int i = 0; i < 8; i++) {
			//devolverLivro()
		}
		
		//Criação do bibliotecário
		Bibliotecario bibliotecario01 = new Bibliotecario();
		bibliotecario01.setNome("Paulo");
		bibliotecario01.setIdade(38);
		
		//Exibindo livros emprestados
		System.out.println(usuario01.getNome() + " emprestou " + usuario01.getLivrosEmprestados() + " livros.");
		System.out.println(usuario02.getNome() + " emprestou " + usuario02.getLivrosEmprestados() + " livros.");
	
	}

}
