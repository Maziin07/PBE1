package br.com.bibliotecasenai.itens;

import br.com.bibliotecasenai.usuarios.Usuario;

public class Emprestimo {

	//ATRIBUTOS
	private int numeroEmprestimo;
	
	//MÉTODOS
	//Emprestar livro
	public void emprestarLivro(Livro livro, Usuario usuario) {
		usuario.setLivrosEmprestados(usuario.getLivrosEmprestados()+1);
	}
	
	//Devolver livro
	public void devolverLivro(Livro livro, Usuario usuario) {
		usuario.setLivrosEmprestados(usuario.getLivrosEmprestados()-1);
	}
}
