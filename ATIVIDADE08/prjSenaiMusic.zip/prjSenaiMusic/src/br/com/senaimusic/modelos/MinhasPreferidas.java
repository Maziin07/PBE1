package br.com.senaimusic.modelos;

public class MinhasPreferidas {

	public void incluir(Audio audio) {
		if(audio.getClassificacao() >= 9) {
			System.out.println(audio.getTitulo() + " foi adicionado, esse é top!");
		}
		else {
			System.out.println(audio.getTitulo() + " foi adicionado, mas não é tão top assim.");
		}
	}
}
