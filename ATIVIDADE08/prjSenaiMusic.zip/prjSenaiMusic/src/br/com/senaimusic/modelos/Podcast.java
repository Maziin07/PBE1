package br.com.senaimusic.modelos;

public class Podcast extends Audio{

	//Atributos
	private String apresentador;
	private String descricao;
	
	//Getters e setters 
	public void setApresentador(String apresentador) {
		this.apresentador = apresentador;
	}
	
	public String getApresentador() {
		return this.apresentador;
	}
	
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	public String getDescricao() {
		return this.descricao; 
	}
	
	@Override
	public double getClassificacao() {
		if(getTotalCurtidas() > 500) {
			return 10;
		}
		else {
			return 8; 
		}
	}
}
