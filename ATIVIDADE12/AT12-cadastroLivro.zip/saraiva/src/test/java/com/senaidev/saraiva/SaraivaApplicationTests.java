package com.senaidev.saraiva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaraivaApplicationTests {

	@Test
	void contextLoads() {
	}

}
