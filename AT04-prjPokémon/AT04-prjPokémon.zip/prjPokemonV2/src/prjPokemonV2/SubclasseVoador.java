package prjPokemonV2;

public class SubclasseVoador extends Pokemon {

	//Metodos da SubClasse
			public void voar() {
				System.out.println(this.nome + " usou voar!");
			}
			
			public void ataquedeasa() {
				System.out.println(this.nome + " usou ataque de asa!");
			}
	
	
}
