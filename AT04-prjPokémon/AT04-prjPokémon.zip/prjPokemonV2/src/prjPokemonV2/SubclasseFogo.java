package prjPokemonV2;

public class SubclasseFogo extends Pokemon {

	//Metodos da SubClasse
			public void bolaFogo() {
				System.out.println(this.nome + " usou Bola de Fogo!");
			}
			
			public void explosaoFogo() {
				System.out.println(this.nome + " usou esplosão de fogo!");
			}
			
			public void lanchaChamas() {
				System.out.println(this.nome + " usou lança chamas!");
			}
	
}
