package prjPokemonV2;

public class SubclasseAgua extends Pokemon {

	 //Metodos da SubClasse
		public void surfar() {
			System.out.println(this.nome + " usou surfar!!");
		}
		
		public void canhaoagua() {
			System.out.println(this.nome + " usou canhão de água!");
		}

	
}
